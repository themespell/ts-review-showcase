<?php
/**
 * Integration Settings for Review Showcase
 *
 * Handles settings for product review display.
 *
 * @package TSReview
 */

namespace TSReview;

use TSReview\Common;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WooCommerceIntegration {

	/**
	 * Block checkout field id for review reminder consent.
	 */
	const BLOCK_CONSENT_FIELD = 'tsreview/review-consent';

	/**
	 * Days a review reward coupon stays valid.
	 */
	const COUPON_VALID_DAYS = 30;

	/**
	 * Initialize the integration settings.
	 */
	public static function init() {
		$self = new self();

		// AJAX handlers for settings
		add_action( 'wp_ajax_tsreview/settings/get', array( $self, 'get_settings' ) );
		add_action( 'wp_ajax_tsreview/settings/save', array( $self, 'save_settings' ) );
		add_action( 'wp_ajax_tsreview/review-form/get', array( $self, 'get_review_form_settings_ajax' ) );
		add_action( 'wp_ajax_tsreview/review-form/save', array( $self, 'save_review_form_settings_ajax' ) );
		add_action( 'wp_ajax_tsreview/emails/send_test', array( $self, 'send_test_email' ) );
		add_action( 'wp_ajax_tsreview/review_reminder/send_test', array( $self, 'send_test_review_reminder' ) );
		add_action( 'wp_ajax_tsreview/messages/send_test', array( $self, 'send_test_message' ) );
		add_action( 'wp_ajax_tsreview/devmode/get_logs', array( $self, 'get_devmode_logs' ) );
		add_action( 'wp_ajax_tsreview/devmode/clear_logs', array( $self, 'clear_devmode_logs' ) );
		add_action( 'wp_ajax_tsreview/devmode/toggle', array( $self, 'toggle_devmode' ) );

		// Override WooCommerce reviews tabs
		add_filter( 'woocommerce_product_tabs', array( $self, 'override_reviews_tab' ), 100 );

		// Replace review form
		add_filter( 'woocommerce_product_review_form_args', array( $self, 'override_review_form' ), 100 );

		add_filter( 'woocommerce_structured_data_product', array( $self, 'filter_product_schema' ), 20, 2 );

		add_action( 'woocommerce_order_status_completed', array( $self, 'schedule_review_reminder_for_order' ) );
		add_action( 'tsreview_send_review_reminder_event', array( $self, 'process_scheduled_review_reminder' ) );
		add_action( 'tsreview_review_submitted', array( $self, 'maybe_send_review_coupon' ), 10, 2 );
		add_action( 'transition_comment_status', array( $self, 'maybe_send_coupon_on_approval' ), 10, 3 );
		add_action( 'woocommerce_review_order_before_submit', array( $self, 'render_checkout_consent' ) );
		add_action( 'woocommerce_checkout_create_order', array( $self, 'save_checkout_consent' ) );
		add_action( 'woocommerce_init', array( $self, 'register_block_checkout_consent' ) );
	}

	/**
	 * Get default grouped plugin settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_settings() {
		return array(
			'general'           => array(
				'default_showcase'    => '',
				'show_review_form'    => true,
				'email_notifications' => true,
				'notification_email'  => get_option( 'admin_email' ),
				'require_purchase'    => false,
				'auto_approve'        => false,
			),
			'review_extensions' => array(
				'enhanced_review_ui'   => true,
				'reviews_per_page'     => 6,
				'sort_order'           => 'recent',
				'disable_lightbox'     => false,
				'show_histogram'       => true,
				'enable_schema'        => true,
				'remove_branding'      => true,
				'verified_owner_label' => '',
				'avatar_mode'          => 'standard',
			),
			'review_discount'   => array(
				'enabled'                  => false,
				'incentivized_badge'       => true,
				'incentivized_badge_label' => 'Incentivized',
				'coupon_type'              => 'percent',
				'coupon_amount'            => 10,
				'coupon_channel'           => 'email',
				'email_bcc'                => '',
				'email_reply_to'           => get_option( 'admin_email' ),
			),
			'trust_badges'      => array(
				'enabled'             => false,
				'badge_label'         => 'Trusted Reviews',
				'show_average_rating' => true,
				'show_review_count'   => true,
				'show_verified_claim' => true,
			),
			'emails'            => array(
				'from_name'               => get_bloginfo( 'name' ),
				'from_email'              => get_option( 'admin_email' ),
				'reply_to'                => get_option( 'admin_email' ),
				'bcc'                     => '',
				'accent_color'            => '#575ECF',
				'review_reminder_heading' => 'We value your feedback',
				'review_reminder_subject' => 'How was your order from {store_name}?',
				'review_reminder_body'    => "Hi {customer_name},\n\nTell us what you think about {product_name}.\n\n{review_link}",
				'review_discount_subject' => 'Your review reward is ready',
				'review_discount_body'    => "Hi {customer_name},\n\nThanks for reviewing {product_name}. Your coupon is {coupon_code}.",
			),
			'messages'          => array(
				'wa_review_reminder_enabled'  => false,
				'wa_review_reminder_template' => 'Hi {customer_name}, how was your order from {store_name}?',
			),
			'review_reminder'   => array(
				'enabled'          => false,
				'manual_enabled'   => false,
				'consent_required' => false,
				'consent_text'     => 'Email me a reminder to review my order.',
				'delay_days'       => 5,
				'sender_name'      => get_bloginfo( 'name' ),
				'shop_name'        => '',
				'enable_for'       => 'all',
				'enable_for_role'  => 'all',
				'enable_for_guests'=> true,
				'language'         => 'EN',
				'tracking_enabled' => false,
			),
		);
	}

	/**
	 * Get sanitized grouped plugin settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_plugin_settings() {
		$defaults = self::get_default_settings();

		$settings = array(
			'general'           => array_merge(
				$defaults['general'],
				array(
					'default_showcase'    => (string) get_option( 'tsreview_default_showcase_id', '' ),
					'show_review_form'    => '1' === get_option( 'tsreview_show_review_form', '1' ),
					'email_notifications' => '1' === get_option( 'tsreview_email_notifications', '1' ),
					'notification_email'  => get_option( 'tsreview_notification_email', $defaults['general']['notification_email'] ),
					'require_purchase'    => '1' === get_option( 'tsreview_require_purchase', '' ),
					'auto_approve'        => '1' === get_option( 'tsreview_auto_approve', '' ),
				)
			),
			'review_extensions' => wp_parse_args( get_option( 'tsreview_settings_review_extensions', array() ), $defaults['review_extensions'] ),
			'review_discount'   => wp_parse_args( get_option( 'tsreview_settings_review_discount', array() ), $defaults['review_discount'] ),
			'trust_badges'      => wp_parse_args( get_option( 'tsreview_settings_trust_badges', array() ), $defaults['trust_badges'] ),
			'emails'            => wp_parse_args( get_option( 'tsreview_settings_emails', array() ), $defaults['emails'] ),
			'messages'          => wp_parse_args( get_option( 'tsreview_settings_messages', array() ), $defaults['messages'] ),
			'review_reminder'   => wp_parse_args( get_option( 'tsreview_settings_review_reminder', array() ), $defaults['review_reminder'] ),
		);

		return self::sanitize_grouped_settings( $settings );
	}

	/**
	 * Settings safe to print on the public site.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_public_feature_settings() {
		$settings = self::get_plugin_settings();

		return array(
			'general'           => array(
				'show_review_form' => ! empty( $settings['general']['show_review_form'] ),
				'require_purchase' => ! empty( $settings['general']['require_purchase'] ),
			),
			'review_extensions' => array(
				'reviews_per_page'     => (int) $settings['review_extensions']['reviews_per_page'],
				'sort_order'           => $settings['review_extensions']['sort_order'],
				'show_histogram'       => ! empty( $settings['review_extensions']['show_histogram'] ),
				'verified_owner_label' => $settings['review_extensions']['verified_owner_label'],
			),
			'review_discount'   => array(
				'enabled'                  => ! empty( $settings['review_discount']['enabled'] ),
				'incentivized_badge'       => ! empty( $settings['review_discount']['incentivized_badge'] ),
				'incentivized_badge_label' => $settings['review_discount']['incentivized_badge_label'],
			),
		);
	}

	/**
	 * Return dev mode logs.
	 *
	 * @return void
	 */
	public function get_devmode_logs() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		wp_send_json_success(
			array(
				'enabled' => Logger::is_enabled(),
				'logs'    => array_reverse( Logger::get_logs() ),
			)
		);
	}

	/**
	 * Clear dev mode logs.
	 *
	 * @return void
	 */
	public function clear_devmode_logs() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		Logger::clear_logs();
		Logger::log( 'devmode.logs_cleared', array(), 'info', true );
		wp_send_json_success( array( 'message' => 'Logs cleared.' ) );
	}

	/**
	 * Toggle dev mode logging.
	 *
	 * @return void
	 */
	public function toggle_devmode() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$enabled = isset( $_POST['enabled'] ) && '1' === (string) wp_unslash( $_POST['enabled'] );
		Logger::set_enabled( $enabled );
		Logger::log( 'devmode.toggled', array( 'enabled' => $enabled ), 'info', true );
		wp_send_json_success( array( 'message' => $enabled ? 'Dev mode enabled.' : 'Dev mode disabled.', 'enabled' => $enabled ) );
	}

	/**
	 * Copy only known groups from an incoming save onto the current settings.
	 * Fields that were not posted stay as they are.
	 *
	 * @param array<string, mixed> $current  Saved settings.
	 * @param array<string, mixed> $incoming Posted settings.
	 * @return array<string, mixed>
	 */
	public static function merge_setting_groups( $current, $incoming ) {
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		if ( ! is_array( $incoming ) ) {
			$incoming = array();
		}

		$merged = $current;
		$groups = array_values( array_intersect( array_keys( $incoming ), array_keys( $current ) ) );

		foreach ( $groups as $group ) {
			if ( ! is_array( $incoming[ $group ] ) || ! isset( $merged[ $group ] ) || ! is_array( $merged[ $group ] ) ) {
				continue;
			}
			foreach ( $incoming[ $group ] as $field => $value ) {
				$merged[ $group ][ $field ] = $value;
			}
		}

		return $merged;
	}

	/**
	 * Sanitize grouped plugin settings.
	 *
	 * @param array<string, mixed> $settings Raw settings.
	 * @return array<string, mixed>
	 */
	private static function sanitize_grouped_settings( $settings ) {
		$defaults = self::get_default_settings();
		$settings = wp_parse_args( is_array( $settings ) ? $settings : array(), $defaults );

		$allowed_sort_order  = array( 'recent', 'rating_high', 'rating_low' );
		$allowed_avatar_mode = array( 'standard', 'initials', 'hidden' );

		return array(
			'general'           => array(
				'default_showcase'    => isset( $settings['general']['default_showcase'] ) ? (string) absint( $settings['general']['default_showcase'] ) : '',
				'show_review_form'    => ! empty( $settings['general']['show_review_form'] ),
				'email_notifications' => ! empty( $settings['general']['email_notifications'] ),
				'notification_email'  => sanitize_email( $settings['general']['notification_email'] ?? $defaults['general']['notification_email'] ),
				'require_purchase'    => ! empty( $settings['general']['require_purchase'] ),
				'auto_approve'        => ! empty( $settings['general']['auto_approve'] ),
			),
			'review_extensions' => array(
				'enhanced_review_ui'   => ! empty( $settings['review_extensions']['enhanced_review_ui'] ),
				'reviews_per_page'     => max( 1, min( 24, absint( $settings['review_extensions']['reviews_per_page'] ?? $defaults['review_extensions']['reviews_per_page'] ) ) ),
				'sort_order'           => in_array( $settings['review_extensions']['sort_order'] ?? '', $allowed_sort_order, true ) ? $settings['review_extensions']['sort_order'] : $defaults['review_extensions']['sort_order'],
				'disable_lightbox'     => ! empty( $settings['review_extensions']['disable_lightbox'] ),
				'show_histogram'       => ! empty( $settings['review_extensions']['show_histogram'] ),
				'enable_schema'        => ! empty( $settings['review_extensions']['enable_schema'] ),
				'remove_branding'      => ! empty( $settings['review_extensions']['remove_branding'] ),
				'verified_owner_label' => sanitize_text_field( $settings['review_extensions']['verified_owner_label'] ?? '' ),
				'avatar_mode'          => in_array( $settings['review_extensions']['avatar_mode'] ?? '', $allowed_avatar_mode, true ) ? $settings['review_extensions']['avatar_mode'] : $defaults['review_extensions']['avatar_mode'],
				'reviews_voting'       => ! empty( $settings['review_extensions']['reviews_voting'] ),
			),
			'review_discount'   => array(
				'enabled'                  => ! empty( $settings['review_discount']['enabled'] ),
				'incentivized_badge'       => ! empty( $settings['review_discount']['incentivized_badge'] ),
				'incentivized_badge_label' => sanitize_text_field( $settings['review_discount']['incentivized_badge_label'] ?? $defaults['review_discount']['incentivized_badge_label'] ),
				'coupon_type'              => 'fixed' === ( $settings['review_discount']['coupon_type'] ?? '' ) ? 'fixed' : 'percent',
				'coupon_amount'            => self::sanitize_coupon_amount( $settings['review_discount']['coupon_type'] ?? 'percent', $settings['review_discount']['coupon_amount'] ?? $defaults['review_discount']['coupon_amount'] ),
				'coupon_channel'           => 'wa' === ( $settings['review_discount']['coupon_channel'] ?? '' ) ? 'wa' : 'email',
				'email_bcc'                => sanitize_email( $settings['review_discount']['email_bcc'] ?? '' ),
				'email_reply_to'           => sanitize_email( $settings['review_discount']['email_reply_to'] ?? $defaults['review_discount']['email_reply_to'] ),
			),
			'trust_badges'      => array(
				'enabled'             => ! empty( $settings['trust_badges']['enabled'] ),
				'badge_label'         => sanitize_text_field( $settings['trust_badges']['badge_label'] ?? $defaults['trust_badges']['badge_label'] ),
				'badge_style'         => sanitize_text_field( $settings['trust_badges']['badge_style'] ?? 'small-light' ),
				'show_average_rating' => ! empty( $settings['trust_badges']['show_average_rating'] ),
				'show_review_count'   => ! empty( $settings['trust_badges']['show_review_count'] ),
				'show_verified_claim' => ! empty( $settings['trust_badges']['show_verified_claim'] ),
				'floating_enabled'    => ! empty( $settings['trust_badges']['floating_enabled'] ),
				'floating_type'       => 'dark' === ( $settings['trust_badges']['floating_type'] ?? '' ) ? 'dark' : 'light',
				'floating_location'   => 'bottomleft' === ( $settings['trust_badges']['floating_location'] ?? '' ) ? 'bottomleft' : 'bottomright',
			),
			'emails'            => array(
				'enabled'                 => ! isset( $settings['emails']['enabled'] ) || ! empty( $settings['emails']['enabled'] ),
				'from_name'               => sanitize_text_field( $settings['emails']['from_name'] ?? $defaults['emails']['from_name'] ),
				'from_email'              => sanitize_email( $settings['emails']['from_email'] ?? $defaults['emails']['from_email'] ),
				'reply_to'                => sanitize_email( $settings['emails']['reply_to'] ?? $defaults['emails']['reply_to'] ),
				'bcc'                     => sanitize_email( $settings['emails']['bcc'] ?? '' ),
				'accent_color'            => sanitize_hex_color( $settings['emails']['accent_color'] ?? $settings['emails']['color'] ?? $defaults['emails']['accent_color'] ) ?: $defaults['emails']['accent_color'],
				'color'                   => sanitize_hex_color( $settings['emails']['color'] ?? $settings['emails']['accent_color'] ?? $defaults['emails']['accent_color'] ) ?: $defaults['emails']['accent_color'],
				'review_reminder_heading' => sanitize_text_field( $settings['emails']['review_reminder_heading'] ?? $defaults['emails']['review_reminder_heading'] ),
				'review_reminder_subject' => sanitize_text_field( $settings['emails']['review_reminder_subject'] ?? $defaults['emails']['review_reminder_subject'] ),
				'review_reminder_body'    => sanitize_textarea_field( $settings['emails']['review_reminder_body'] ?? $defaults['emails']['review_reminder_body'] ),
				'review_discount_heading' => sanitize_text_field( $settings['emails']['review_discount_heading'] ?? '' ),
				'review_discount_subject' => sanitize_text_field( $settings['emails']['review_discount_subject'] ?? $defaults['emails']['review_discount_subject'] ),
				'review_discount_body'    => sanitize_textarea_field( $settings['emails']['review_discount_body'] ?? $defaults['emails']['review_discount_body'] ),
			),
			'messages'          => array(
				'wa_review_reminder_enabled'  => ! empty( $settings['messages']['wa_review_reminder_enabled'] ),
				'wa_review_reminder_template' => sanitize_textarea_field( $settings['messages']['wa_review_reminder_template'] ?? $defaults['messages']['wa_review_reminder_template'] ),
			),
			'review_reminder'   => array(
				'enabled'          => ! empty( $settings['review_reminder']['enabled'] ),
				'manual_enabled'   => ! empty( $settings['review_reminder']['manual_enabled'] ),
				'consent_required' => ! empty( $settings['review_reminder']['consent_required'] ),
				'consent_text'     => sanitize_textarea_field( $settings['review_reminder']['consent_text'] ?? $defaults['review_reminder']['consent_text'] ),
				'delay_days'       => max( 1, min( 60, absint( $settings['review_reminder']['delay_days'] ?? $defaults['review_reminder']['delay_days'] ) ) ),
				'sender_name'      => sanitize_text_field( $settings['review_reminder']['sender_name'] ?? $defaults['review_reminder']['sender_name'] ),
				'shop_name'        => sanitize_text_field( $settings['review_reminder']['shop_name'] ?? '' ),
				'enable_for'       => 'categories' === ( $settings['review_reminder']['enable_for'] ?? '' ) ? 'categories' : 'all',
				'enable_for_role'  => 'roles' === ( $settings['review_reminder']['enable_for_role'] ?? '' ) ? 'roles' : 'all',
				'enable_for_guests'=> ! empty( $settings['review_reminder']['enable_for_guests'] ),
				'language'         => sanitize_text_field( $settings['review_reminder']['language'] ?? 'EN' ),
				'tracking_enabled' => ! empty( $settings['review_reminder']['tracking_enabled'] ),
			),
		);
	}

	/**
	 * Get settings via AJAX.
	 */
	public function get_settings() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$settings = self::get_plugin_settings();

		wp_send_json_success(
			array_merge(
				$settings,
				array(
					'default_showcase' => $settings['general']['default_showcase'],
					'show_review_form' => $settings['general']['show_review_form'] ? '1' : '',
				)
			)
		);
	}

	/**
	 * Save settings via AJAX.
	 */
	public function save_settings() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$raw_settings = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : null;
		$settings = array();

		if ( is_string( $raw_settings ) ) {
			$decoded = json_decode( $raw_settings, true );
			$settings = is_array( $decoded ) ? $decoded : array();
		}

		if ( empty( $settings ) ) {
			$settings = array(
				'general' => array(
					'default_showcase' => isset( $_POST['default_showcase'] ) ? wp_unslash( $_POST['default_showcase'] ) : '',
					'show_review_form' => isset( $_POST['show_review_form'] ),
				),
			);
		}

		$current = self::get_plugin_settings();
		$groups  = array_values( array_intersect( array_keys( $settings ), array_keys( $current ) ) );
		$merged  = self::merge_setting_groups( $current, $settings );

		$sanitized = self::sanitize_grouped_settings( $merged );

		if ( in_array( 'general', $groups, true ) ) {
			update_option( 'tsreview_default_showcase_id', absint( $sanitized['general']['default_showcase'] ) );
			update_option( 'tsreview_show_review_form', $sanitized['general']['show_review_form'] ? '1' : '' );
			update_option( 'tsreview_email_notifications', $sanitized['general']['email_notifications'] ? '1' : '' );
			update_option( 'tsreview_notification_email', $sanitized['general']['notification_email'] );
			update_option( 'tsreview_require_purchase', $sanitized['general']['require_purchase'] ? '1' : '' );
			update_option( 'tsreview_auto_approve', $sanitized['general']['auto_approve'] ? '1' : '' );
		}

		$option_map = array(
			'review_extensions' => 'tsreview_settings_review_extensions',
			'review_discount'   => 'tsreview_settings_review_discount',
			'trust_badges'      => 'tsreview_settings_trust_badges',
			'emails'            => 'tsreview_settings_emails',
			'messages'          => 'tsreview_settings_messages',
			'review_reminder'   => 'tsreview_settings_review_reminder',
		);

		foreach ( $option_map as $group => $option_key ) {
			if ( in_array( $group, $groups, true ) ) {
				update_option( $option_key, $sanitized[ $group ] );
			}
		}

		wp_send_json_success( array( 'message' => 'Settings saved successfully', 'settings' => $sanitized ) );
	}

	/**
	 * Return default review form settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_review_form_settings() {
		return array(
			'id'           => 'default-review-form',
			'name'         => 'Product page reviews',
			'preset'       => 'card',
			'accent'       => '#2563eb',
			'background'   => '#ffffff',
			'text'         => '#0f172a',
			'radius'       => 16,
			'spacing'      => 2,
			'font'         => 'sans',
			'showLabels'   => true,
			'buttonLabel'  => 'Submit review',
			'buttonStyle'  => 'solid',
			'sections'     => array(
				array(
					'id'         => 'default-section',
					'background' => '',
					'paddingY'   => 16,
					'paddingX'   => 0,
					'gap'        => 16,
					'columns'    => array(
						array(
							'id'      => 'default-column',
							'width'   => '1/1',
							'align'   => 'top',
							'widgets' => array(
								array( 'id' => 'w-heading', 'type' => 'heading', 'settings' => array( 'text' => 'Write a review', 'level' => 'h3' ) ),
								array( 'id' => 'w-paragraph', 'type' => 'paragraph', 'settings' => array( 'text' => 'Share your experience with others.' ) ),
								array( 'id' => 'w-name', 'type' => 'name', 'settings' => array( 'label' => 'Your name', 'placeholder' => 'Jane Doe', 'required' => true ) ),
								array( 'id' => 'w-email', 'type' => 'email', 'settings' => array( 'label' => 'Email', 'placeholder' => 'jane@example.com', 'required' => true ) ),
								array( 'id' => 'w-rating', 'type' => 'rating', 'settings' => array( 'label' => 'Rating', 'required' => true ) ),
								array( 'id' => 'w-title', 'type' => 'title', 'settings' => array( 'label' => 'Headline', 'placeholder' => 'Sum it up in a few words', 'required' => false ) ),
								array( 'id' => 'w-review', 'type' => 'review', 'settings' => array( 'label' => 'Your review', 'placeholder' => 'Tell others what you thought...', 'required' => true ) ),
								array( 'id' => 'w-button', 'type' => 'button', 'settings' => array( 'label' => 'Submit review', 'buttonStyle' => 'solid' ) ),
							),
						),
					),
				),
			),
			'updatedAt'    => time(),
		);
	}

	/**
	 * Get saved review form settings merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_review_form_settings() {
		$saved = get_option( 'tsreview_review_form_settings', array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		return self::sanitize_review_form_settings( array_merge( self::get_default_review_form_settings(), $saved ) );
	}

	/**
	 * Sanitize review form settings.
	 *
	 * @param array<string, mixed> $settings Settings to sanitize.
	 * @return array<string, mixed>
	 */
	private static function sanitize_review_form_settings( $settings ) {
		$defaults = self::get_default_review_form_settings();
		$merged   = array_merge( $defaults, is_array( $settings ) ? $settings : array() );
		$allowed_presets = array( 'minimal', 'card', 'editorial', 'playful', 'brutalist' );
		$allowed_fonts = array( 'sans', 'serif' );
		$allowed_button_styles = array( 'solid', 'outline', 'ghost' );
		$allowed_widths = array( '1/1', '1/2', '1/3', '2/3', '1/4', '3/4' );
		$allowed_aligns = array( 'top', 'center', 'bottom' );
		$allowed_widgets = array( 'name', 'email', 'rating', 'title', 'review', 'divider', 'spacer', 'heading', 'paragraph', 'button' );
		$allowed_levels = array( 'h2', 'h3', 'h4' );
		$allowed_divider_styles = array( 'solid', 'dashed', 'dotted' );

		$sections = array();
		if ( isset( $merged['sections'] ) && is_array( $merged['sections'] ) ) {
			foreach ( $merged['sections'] as $section ) {
				if ( empty( $section['id'] ) ) {
					continue;
				}

				$columns = array();
				if ( isset( $section['columns'] ) && is_array( $section['columns'] ) ) {
					foreach ( $section['columns'] as $column ) {
						if ( empty( $column['id'] ) ) {
							continue;
						}

						$widgets = array();
						if ( isset( $column['widgets'] ) && is_array( $column['widgets'] ) ) {
							foreach ( $column['widgets'] as $widget ) {
								if ( empty( $widget['id'] ) || empty( $widget['type'] ) || ! in_array( $widget['type'], $allowed_widgets, true ) ) {
									continue;
								}

								$widget_settings = isset( $widget['settings'] ) && is_array( $widget['settings'] ) ? $widget['settings'] : array();
								$sanitized_widget = array(
									'id'       => sanitize_text_field( $widget['id'] ),
									'type'     => sanitize_key( $widget['type'] ),
									'settings' => array(),
								);

								if ( isset( $widget_settings['label'] ) ) {
									$sanitized_widget['settings']['label'] = sanitize_text_field( $widget_settings['label'] );
								}
								if ( isset( $widget_settings['placeholder'] ) ) {
									$sanitized_widget['settings']['placeholder'] = sanitize_text_field( $widget_settings['placeholder'] );
								}
								if ( isset( $widget_settings['required'] ) ) {
									$sanitized_widget['settings']['required'] = ! empty( $widget_settings['required'] );
								}
								if ( isset( $widget_settings['text'] ) ) {
									$sanitized_widget['settings']['text'] = sanitize_text_field( $widget_settings['text'] );
								}
								if ( isset( $widget_settings['level'] ) && in_array( $widget_settings['level'], $allowed_levels, true ) ) {
									$sanitized_widget['settings']['level'] = $widget_settings['level'];
								}
								if ( isset( $widget_settings['thickness'] ) ) {
									$sanitized_widget['settings']['thickness'] = max( 1, absint( $widget_settings['thickness'] ) );
								}
								if ( isset( $widget_settings['dividerStyle'] ) && in_array( $widget_settings['dividerStyle'], $allowed_divider_styles, true ) ) {
									$sanitized_widget['settings']['dividerStyle'] = $widget_settings['dividerStyle'];
								}
								if ( isset( $widget_settings['height'] ) ) {
									$sanitized_widget['settings']['height'] = max( 0, absint( $widget_settings['height'] ) );
								}
								if ( isset( $widget_settings['buttonStyle'] ) && in_array( $widget_settings['buttonStyle'], $allowed_button_styles, true ) ) {
									$sanitized_widget['settings']['buttonStyle'] = $widget_settings['buttonStyle'];
								}

								$widgets[] = $sanitized_widget;
							}
						}

						$columns[] = array(
							'id'      => sanitize_text_field( $column['id'] ),
							'width'   => in_array( $column['width'], $allowed_widths, true ) ? $column['width'] : '1/1',
							'align'   => in_array( $column['align'], $allowed_aligns, true ) ? $column['align'] : 'top',
							'widgets' => $widgets,
						);
					}
				}

				if ( empty( $columns ) ) {
					continue;
				}

				$sections[] = array(
					'id'         => sanitize_text_field( $section['id'] ),
					'background' => isset( $section['background'] ) ? sanitize_hex_color( $section['background'] ) : '',
					'paddingY'   => isset( $section['paddingY'] ) ? max( 0, absint( $section['paddingY'] ) ) : 16,
					'paddingX'   => isset( $section['paddingX'] ) ? max( 0, absint( $section['paddingX'] ) ) : 0,
					'gap'        => isset( $section['gap'] ) ? max( 0, absint( $section['gap'] ) ) : 16,
					'columns'    => $columns,
				);
			}
		}

		return array(
			'id'          => isset( $merged['id'] ) ? sanitize_text_field( $merged['id'] ) : $defaults['id'],
			'name'        => isset( $merged['name'] ) ? sanitize_text_field( $merged['name'] ) : $defaults['name'],
			'preset'      => isset( $merged['preset'] ) && in_array( $merged['preset'], $allowed_presets, true ) ? $merged['preset'] : $defaults['preset'],
			'accent'      => isset( $merged['accent'] ) ? sanitize_hex_color( $merged['accent'] ) : $defaults['accent'],
			'background'  => isset( $merged['background'] ) ? sanitize_hex_color( $merged['background'] ) : $defaults['background'],
			'text'        => isset( $merged['text'] ) ? sanitize_hex_color( $merged['text'] ) : $defaults['text'],
			'radius'      => isset( $merged['radius'] ) ? max( 0, absint( $merged['radius'] ) ) : $defaults['radius'],
			'spacing'     => isset( $merged['spacing'] ) ? max( 0, min( 3, absint( $merged['spacing'] ) ) ) : $defaults['spacing'],
			'font'        => isset( $merged['font'] ) && in_array( $merged['font'], $allowed_fonts, true ) ? $merged['font'] : $defaults['font'],
			'showLabels'  => ! empty( $merged['showLabels'] ),
			'buttonLabel' => isset( $merged['buttonLabel'] ) ? sanitize_text_field( $merged['buttonLabel'] ) : $defaults['buttonLabel'],
			'buttonStyle' => isset( $merged['buttonStyle'] ) && in_array( $merged['buttonStyle'], $allowed_button_styles, true ) ? $merged['buttonStyle'] : $defaults['buttonStyle'],
			'sections'    => ! empty( $sections ) ? $sections : $defaults['sections'],
			'updatedAt'   => time(),
		);
	}

	/**
	 * Get review form settings via AJAX.
	 */
	public function get_review_form_settings_ajax() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		wp_send_json_success( self::get_review_form_settings() );
	}

	/**
	 * Save review form settings via AJAX.
	 */
	public function save_review_form_settings_ajax() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$settings = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();
		if ( is_string( $settings ) ) {
			$decoded = json_decode( $settings, true );
			$settings = is_array( $decoded ) ? $decoded : array();
		}

		$sanitized = self::sanitize_review_form_settings( $settings );
		update_option( 'tsreview_review_form_settings', $sanitized );

		wp_send_json_success(
			array(
				'message'  => 'Review form settings saved successfully',
				'settings' => $sanitized,
			)
		);
	}

	/**
	 * Send a configured test email.
	 *
	 * @return void
	 */
	public function send_test_email() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$to       = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$template = isset( $_POST['template'] ) ? sanitize_key( wp_unslash( $_POST['template'] ) ) : 'review_reminder';

		if ( ! is_email( $to ) ) {
			Logger::log( 'email.test.invalid_recipient', array( 'template' => $template ), 'warning', true );
			wp_send_json_error( array( 'message' => 'Valid test email required.' ) );
		}

		$plugin_settings = self::get_plugin_settings();
		$email_settings  = $plugin_settings['emails'];
		$subject         = 'review_discount' === $template ? $email_settings['review_discount_subject'] : $email_settings['review_reminder_subject'];
		$body            = 'review_discount' === $template ? $email_settings['review_discount_body'] : $email_settings['review_reminder_body'];
		$tokens          = array(
			'{store_name}'    => get_bloginfo( 'name' ),
			'{customer_name}' => 'Test Customer',
			'{product_name}'  => 'Sample Product',
			'{review_link}'   => home_url( '/product/sample-product/#reviews' ),
			'{coupon_code}'   => 'TSREVIEW10',
		);

		$sent = $this->send_configured_email(
			$to,
			$this->replace_tokens( $subject, $tokens ),
			$this->replace_tokens( $body, $tokens ),
			'Test Email'
		);

		if ( $sent ) {
			Logger::log( 'email.test.sent', array( 'to' => $to, 'template' => $template ) );
			wp_send_json_success( array( 'message' => 'Test email sent.' ) );
		}

		Logger::log( 'email.test.failed', array( 'to' => $to, 'template' => $template ), 'error', true );
		wp_send_json_error( array( 'message' => 'wp_mail failed while sending test email.' ) );
	}

	/**
	 * Send a manual test reminder email.
	 *
	 * @return void
	 */
	public function send_test_review_reminder() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$to = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $to ) ) {
			Logger::log( 'reminder.test.invalid_recipient', array(), 'warning', true );
			wp_send_json_error( array( 'message' => 'Valid reminder email required.' ) );
		}

		$sent = $this->send_review_reminder_email(
			$to,
			'Test Customer',
			'Sample Product',
			home_url( '/product/sample-product/#reviews' )
		);

		if ( $sent ) {
			Logger::log( 'reminder.test.sent', array( 'to' => $to ) );
			wp_send_json_success( array( 'message' => 'Test reminder sent.' ) );
		}

		Logger::log( 'reminder.test.failed', array( 'to' => $to ), 'error', true );
		wp_send_json_error( array( 'message' => 'wp_mail failed while sending test reminder.' ) );
	}

	/**
	 * Send test message through external provider hook.
	 *
	 * @return void
	 */
	public function send_test_message() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
		}

		$recipient = isset( $_POST['recipient'] ) ? sanitize_text_field( wp_unslash( $_POST['recipient'] ) ) : '';
		if ( '' === $recipient ) {
			Logger::log( 'message.test.invalid_recipient', array(), 'warning', true );
			wp_send_json_error( array( 'message' => 'Recipient is required.' ) );
		}

		$plugin_settings = self::get_plugin_settings();
		$template        = $plugin_settings['messages']['wa_review_reminder_template'];
		$message         = $this->replace_tokens(
			$template,
			array(
				'{store_name}'    => get_bloginfo( 'name' ),
				'{customer_name}' => 'Test Customer',
			)
		);

		$result = apply_filters(
			'tsreview_send_test_message',
			array(
				'success' => false,
				'message' => 'No message provider configured for ts-review-showcase.',
			),
			array(
				'recipient' => $recipient,
				'message'   => $message,
			)
		);

		if ( ! empty( $result['success'] ) ) {
			Logger::log( 'message.test.sent', array( 'recipient' => $recipient ) );
			wp_send_json_success( array( 'message' => $result['message'] ?? 'Test message sent.' ) );
		}

		Logger::log( 'message.test.failed', array( 'recipient' => $recipient, 'reason' => $result['message'] ?? 'provider_not_configured' ), 'error', true );
		wp_send_json_error( array( 'message' => $result['message'] ?? 'No message provider configured.' ) );
	}

	/**
	 * Override WooCommerce reviews tab.
	 */
	public function override_reviews_tab( $tabs ) {
		$product = wc_get_product();

		if ( ! $product ) {
			return $tabs;
		}

		$showcase_id = $this->get_showcase_id_for_product();

		// If no showcase selected globally, return default tabs
		if ( ! $showcase_id ) {
			return $tabs;
		}

		// Override the reviews tab
		if ( isset( $tabs['reviews'] ) ) {
			$tabs['reviews']['callback'] = array( $this, 'render_custom_reviews' );
			$tabs['reviews']['title']     = esc_html__( 'Reviews', 'ts-review-showcase' );
		}

		return $tabs;
	}

	/**
	 * Render custom review showcase content.
	 */
	public function render_custom_reviews( $comments ) {
		$product = wc_get_product();

		if ( ! $product ) {
			return;
		}

		$showcase_id = $this->get_showcase_id_for_product();

		if ( ! $showcase_id ) {
			// Fallback to default
			comments_template();
			return;
		}

		$show_form = get_option( 'tsreview_show_review_form', '1' );

		// Get review count
		$count = $product->get_review_count();

		// Output the review showcase with form
		echo '<div id="reviews" class="woocommerce-Reviews ts-review-showcase-wrapper">';
		echo '<div id="comments">';
		echo '<h2 class="woocommerce-Reviews-title">';

		if ( $count ) {
			/* translators: 1: Review count, 2: Product title */
			printf( esc_html( _n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'ts-review-showcase' ) ), esc_html( $count ), '<span>' . esc_html( get_the_title() ) . '</span>' );
		} else {
			esc_html_e( 'Reviews', 'ts-review-showcase' );
		}

		echo '</h2>';

		$this->render_trust_badge( $product );

		// Review Showcase
		echo '<div class="ts-review-showcase" data-id="' . esc_attr( $showcase_id ) . '" data-product-id="' . esc_attr( $product->get_id() ) . '"></div>';

		// Review Form - Always rendered, React handles the toggle
		if ( $show_form ) {
			echo '<div class="tsreview-woocommerce-form-wrapper" style="margin-top: 24px;">';
			echo '<div class="ts-review-form-container" data-product-id="' . esc_attr( $product->get_id() ) . '"></div>';
			echo '</div>';
		}

		echo '</div></div>';
	}

	/**
	 * Render trust badge summary.
	 *
	 * @param \WC_Product $product Product instance.
	 * @return void
	 */
	private function render_trust_badge( $product ) {
		$settings = self::get_plugin_settings();
		$badge    = $settings['trust_badges'];

		if ( empty( $badge['enabled'] ) || ! $product ) {
			return;
		}

		$review_count   = (int) $product->get_review_count();
		$average_rating = (float) $product->get_average_rating();
		$verified_text  = $settings['review_extensions']['verified_owner_label'] ? $settings['review_extensions']['verified_owner_label'] : __( 'Verified owner', 'ts-review-showcase' );

		echo '<div class="tsreview-trust-badge" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 20px;padding:14px 16px;border:1px solid rgba(87,94,207,0.12);border-radius:14px;background:linear-gradient(135deg, rgba(87,94,207,0.06), rgba(139,123,255,0.04));">';
		echo '<strong style="color:#1f2340;">' . esc_html( $badge['badge_label'] ) . '</strong>';

		if ( ! empty( $badge['show_average_rating'] ) ) {
			echo '<span style="color:#575ecf;font-weight:600;">' . esc_html( number_format_i18n( $average_rating, 1 ) ) . '/5</span>';
		}

		if ( ! empty( $badge['show_review_count'] ) ) {
			echo '<span style="color:#4b5563;">' . esc_html( sprintf( _n( '%s review', '%s reviews', $review_count, 'ts-review-showcase' ), number_format_i18n( $review_count ) ) ) . '</span>';
		}

		// Claim "verified" only when the product has at least one verified review.
		$has_verified = ! empty( $badge['show_verified_claim'] ) && get_comments(
			array(
				'post_id'    => $product->get_id(),
				'type'       => 'review',
				'status'     => 'approve',
				'meta_key'   => 'verified', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
				'count'      => true,
			)
		) > 0;

		if ( $has_verified ) {
			echo '<span style="color:#15803d;">' . esc_html( $verified_text ) . '</span>';
		}

		echo '</div>';
	}

	/**
	 * Get the showcase ID from global settings.
	 */
	private function get_showcase_id_for_product() {
		$showcase_id = get_option( 'tsreview_default_showcase_id', 0 );

		// Return showcase_id if it's a valid positive integer
		return $showcase_id && $showcase_id > 0 ? absint( $showcase_id ) : null;
	}

	/**
	 * Return custom CSS to hide the default WooCommerce form.
	 */
	public static function get_custom_css() {
		return '
		.tsreview-hidden-form,
		.woocommerce-Reviews .comment-respond {
			display: none !important;
		}

		.ts-review-form-container {
			display: block !important;
		}

		.tsreview-woocommerce-form-wrapper {
			display: block !important;
		}';
	}

	/**
	 * Override the default review form - we render our own form.
	 */
	public function override_review_form( $args ) {
		$product = wc_get_product();

		if ( ! $product ) {
			return $args;
		}

		$showcase_id = $this->get_showcase_id_for_product();

		if ( ! $showcase_id ) {
			return $args;
		}

		// Return empty args to hide default WooCommerce form
		return array(
			'class'        => 'tsreview-hidden-form',
			'title_reply'  => '',
			'label_submit' => '',
			'comment_field' => '',
		);
	}

	/**
	 * Output review data through WooCommerce product schema instead of a second JSON-LD block.
	 *
	 * @param array       $markup  Product schema.
	 * @param \WC_Product $product Product.
	 * @return array
	 */
	public function filter_product_schema( $markup, $product ) {
		$settings = self::get_plugin_settings();
		if ( empty( $settings['review_extensions']['enable_schema'] ) ) {
			unset( $markup['aggregateRating'], $markup['review'] );
			return $markup;
		}

		if ( ! $product || (int) $product->get_review_count() < 1 ) {
			unset( $markup['aggregateRating'], $markup['review'] );
		}

		return $markup;
	}

	/**
	 * Checkout consent for review reminder emails.
	 *
	 * @return void
	 */
	public function render_checkout_consent() {
		$settings = self::get_plugin_settings();
		if ( empty( $settings['review_reminder']['enabled'] ) || empty( $settings['review_reminder']['consent_required'] ) ) {
			return;
		}

		$label = $settings['review_reminder']['consent_text'] ? $settings['review_reminder']['consent_text'] : __( 'Email me a reminder to review my order.', 'ts-review-showcase' );
		echo '<p class="form-row tsreview-consent"><label><input type="checkbox" name="tsreview_review_consent" value="1" /> ' . esc_html( $label ) . '</label></p>';
	}

	/**
	 * Store checkout consent on the order.
	 *
	 * @param \WC_Order $order Order.
	 * @return void
	 */
	public function save_checkout_consent( $order ) {
		if ( ! empty( $_POST['tsreview_review_consent'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the checkout nonce.
			$order->update_meta_data( '_tsreview_review_consent', 'yes' );
		}
	}

	/**
	 * The same consent checkbox for the block-based Checkout (WooCommerce 8.9+).
	 * Block checkout ignores the classic woocommerce_review_order_before_submit hook.
	 *
	 * @return void
	 */
	public function register_block_checkout_consent() {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}

		$settings = self::get_plugin_settings();
		if ( empty( $settings['review_reminder']['enabled'] ) || empty( $settings['review_reminder']['consent_required'] ) ) {
			return;
		}

		$label = $settings['review_reminder']['consent_text'] ? $settings['review_reminder']['consent_text'] : __( 'Email me a reminder to review my order.', 'ts-review-showcase' );

		woocommerce_register_additional_checkout_field(
			array(
				'id'       => self::BLOCK_CONSENT_FIELD,
				'label'    => $label,
				'location' => 'order',
				'type'     => 'checkbox',
			)
		);
	}

	/**
	 * Whether the customer agreed to a review reminder on either checkout.
	 *
	 * @param \WC_Order $order Order.
	 * @return bool
	 */
	private function order_has_consent( $order ) {
		if ( 'yes' === $order->get_meta( '_tsreview_review_consent', true ) ) {
			return true;
		}

		// Block checkout stores additional order fields as _wc_other/{field id}.
		$block_value = $order->get_meta( '_wc_other/' . self::BLOCK_CONSENT_FIELD, true );
		return ! empty( $block_value ) && 'false' !== $block_value;
	}

	/**
	 * Email one coupon after a review is approved.
	 *
	 * @param string $new_status New comment status.
	 * @param string $old_status Old comment status.
	 * @param \WP_Comment $comment Comment.
	 * @return void
	 */
	public function maybe_send_coupon_on_approval( $new_status, $old_status, $comment ) {
		if ( 'approved' !== $new_status || 'approved' === $old_status || ! $comment instanceof \WP_Comment ) {
			return;
		}

		if ( 'review' !== $comment->comment_type ) {
			return;
		}

		$this->maybe_send_review_coupon(
			array(
				'comment_ID'     => $comment->comment_ID,
				'reviewer_name'  => $comment->comment_author,
				'reviewer_email' => $comment->comment_author_email,
			),
			(int) $comment->comment_post_ID
		);
	}

	public function maybe_send_review_coupon( $review_data, $product_id ) {
		$settings = self::get_plugin_settings();
		if ( empty( $settings['review_discount']['enabled'] ) || ! class_exists( 'WC_Coupon' ) ) {
			return;
		}

		$email = isset( $review_data['reviewer_email'] ) ? sanitize_email( $review_data['reviewer_email'] ) : '';
		$comment_id = isset( $review_data['comment_ID'] ) ? (int) $review_data['comment_ID'] : 0;
		$comment    = $comment_id ? get_comment( $comment_id ) : null;
		if ( ! is_email( $email ) || ! $comment || '1' !== (string) $comment->comment_approved ) {
			return;
		}

		if ( get_comment_meta( $comment_id, '_tsreview_coupon_code', true ) || (int) $comment->comment_parent > 0 ) {
			return;
		}

		// Reward only real buyers. Otherwise anyone could farm coupons with
		// throwaway emails across many products.
		$requires_purchase = (bool) apply_filters( 'tsreview_reward_requires_purchase', true, $comment, $product_id );
		if ( $requires_purchase && ! $this->is_verified_buyer( $email, (int) $comment->user_id, (int) $product_id ) ) {
			Logger::log( 'reward.skipped_unverified', array( 'comment_id' => $comment_id, 'product_id' => $product_id ) );
			return;
		}

		$already_rewarded = get_comments(
			array(
				'post_id'      => (int) $product_id,
				'author_email' => $email,
				'type'         => 'review',
				'meta_key'     => '_tsreview_coupon_code',
				'count'        => true,
			)
		);
		if ( $already_rewarded ) {
			return;
		}

		$discount = $settings['review_discount'];
		$type     = 'fixed' === $discount['coupon_type'] ? 'fixed_cart' : 'percent';
		$amount   = $discount['coupon_amount'];

		$code   = 'tsr' . strtolower( wp_generate_password( 8, false, false ) );
		$coupon = new \WC_Coupon();
		$coupon->set_code( $code );
		$coupon->set_discount_type( $type );
		$coupon->set_amount( $amount );
		$coupon->set_individual_use( true );
		$coupon->set_usage_limit( 1 );
		$coupon->set_usage_limit_per_user( 1 );
		$coupon->set_email_restrictions( array( $email ) );
		$coupon->set_date_expires( time() + (int) apply_filters( 'tsreview_reward_coupon_days', self::COUPON_VALID_DAYS ) * DAY_IN_SECONDS );
		$coupon->set_description(
			/* translators: %d: review comment ID */
			sprintf( __( 'TS Review reward for review #%d', 'ts-review-showcase' ), $comment_id )
		);
		$coupon->save();

		update_comment_meta( $comment_id, '_tsreview_incentivized', 'yes' );
		update_comment_meta( $comment_id, '_tsreview_coupon_code', $code );

		$product_name = get_the_title( $product_id );
		$this->send_review_discount_email(
			$email,
			isset( $review_data['reviewer_name'] ) ? $review_data['reviewer_name'] : '',
			$product_name ? $product_name : __( 'your product', 'ts-review-showcase' ),
			$code
		);
	}

	/**
	 * Whether this email or user bought the product in a paid order.
	 *
	 * @param string $email      Reviewer email.
	 * @param int    $user_id    Reviewer user ID, 0 for guests.
	 * @param int    $product_id Product ID.
	 * @return bool
	 */
	private function is_verified_buyer( $email, $user_id, $product_id ) {
		if ( ! function_exists( 'wc_customer_bought_product' ) ) {
			return false;
		}

		return (bool) wc_customer_bought_product( $email, $user_id, $product_id );
	}

	/**
	 * @param string $type   percent or fixed.
	 * @param mixed  $amount Raw amount.
	 * @return float
	 */
	private static function sanitize_coupon_amount( $type, $amount ) {
		$amount = (float) $amount;
		if ( 'fixed' === $type ) {
			return max( 1, $amount );
		}
		return max( 1, min( 100, $amount ) );
	}

	/**
	 * Schedule reminder when order completed.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function schedule_review_reminder_for_order( $order_id ) {
		$settings = self::get_plugin_settings();
		if ( empty( $settings['review_reminder']['enabled'] ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			Logger::log( 'reminder.schedule.order_missing', array( 'order_id' => $order_id ), 'warning', true );
			return;
		}

		if ( 'yes' === $order->get_meta( '_tsreview_reminder_sent', true ) || 'yes' === $order->get_meta( '_tsreview_reminder_scheduled', true ) ) {
			Logger::log( 'reminder.schedule.skipped_duplicate', array( 'order_id' => $order_id ) );
			return;
		}

		if ( ! empty( $settings['review_reminder']['consent_required'] ) && ! $this->order_has_consent( $order ) ) {
			Logger::log( 'reminder.schedule.skipped_consent', array( 'order_id' => $order_id ) );
			return;
		}

		$delay = max( 1, absint( $settings['review_reminder']['delay_days'] ) ) * DAY_IN_SECONDS;
		wp_schedule_single_event( time() + $delay, 'tsreview_send_review_reminder_event', array( $order_id ) );
		$order->update_meta_data( '_tsreview_reminder_scheduled', 'yes' );
		$order->update_meta_data( '_tsreview_reminder_scheduled_at', time() + $delay );
		$order->save();
		Logger::log( 'reminder.schedule.created', array( 'order_id' => $order_id, 'send_at' => time() + $delay ) );
	}

	/**
	 * Process scheduled reminder event.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function process_scheduled_review_reminder( $order_id ) {
		$settings = self::get_plugin_settings();
		$order    = wc_get_order( $order_id );
		if ( empty( $settings['review_reminder']['enabled'] ) || ! $order || 'yes' === $order->get_meta( '_tsreview_reminder_sent', true ) ) {
			Logger::log( 'reminder.process.skipped', array( 'order_id' => $order_id ), 'warning', true );
			return;
		}

		if ( ! $order->has_status( 'completed' ) ) {
			Logger::log( 'reminder.process.skipped_status', array( 'order_id' => $order_id, 'status' => $order->get_status() ) );
			return;
		}

		$email = $order->get_billing_email();
		if ( ! is_email( $email ) ) {
			Logger::log( 'reminder.process.invalid_email', array( 'order_id' => $order_id ), 'error', true );
			return;
		}

		$pending = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}

			$product_id = $product->is_type( 'variation' ) ? (int) $product->get_parent_id() : (int) $product->get_id();
			if ( ! $product_id || isset( $pending[ $product_id ] ) ) {
				continue;
			}

			if ( $this->customer_already_reviewed( $email, $product_id ) ) {
				continue;
			}

			$parent = $product->is_type( 'variation' ) ? wc_get_product( $product_id ) : $product;
			$name   = $parent ? $parent->get_name() : $product->get_name();
			$link   = get_permalink( $product_id );
			$pending[ $product_id ] = array(
				'name' => $name ? $name : __( 'your product', 'ts-review-showcase' ),
				'link' => $link ? $link . '#reviews' : '',
			);
		}

		if ( empty( $pending ) ) {
			$order->update_meta_data( '_tsreview_reminder_sent', 'yes' );
			$order->update_meta_data( '_tsreview_reminder_skipped', 'already_reviewed' );
			$order->save();
			Logger::log( 'reminder.process.nothing_pending', array( 'order_id' => $order_id ) );
			return;
		}

		$names = array();
		$links = array();
		foreach ( $pending as $row ) {
			$names[] = $row['name'];
			$links[] = $row['link'] ? $row['name'] . "\n" . $row['link'] : $row['name'];
		}

		$first       = reset( $pending );
		$review_link = 1 === count( $pending ) ? $first['link'] : implode( "\n\n", $links );
		$sent        = $this->send_review_reminder_email(
			$email,
			$order->get_billing_first_name() ? $order->get_billing_first_name() : 'Customer',
			implode( ', ', $names ),
			$review_link
		);

		if ( $sent ) {
			$order->update_meta_data( '_tsreview_reminder_sent', 'yes' );
			$order->update_meta_data( '_tsreview_reminder_sent_at', time() );
			$order->save();
			Logger::log( 'reminder.process.sent', array( 'order_id' => $order_id, 'email' => $email, 'products' => count( $pending ) ) );
			return;
		}

		$attempts = (int) $order->get_meta( '_tsreview_reminder_attempts', true );
		if ( $attempts < 3 ) {
			$order->update_meta_data( '_tsreview_reminder_attempts', $attempts + 1 );
			$order->save();
			wp_schedule_single_event( time() + HOUR_IN_SECONDS, 'tsreview_send_review_reminder_event', array( (int) $order_id ) );
		}
		Logger::log( 'reminder.process.failed', array( 'order_id' => $order_id, 'email' => $email, 'attempts' => $attempts + 1 ), 'error', true );
	}

	/**
	 * Whether this customer already left a review on the product.
	 *
	 * @param string $email Customer email.
	 * @param int    $product_id Product ID.
	 * @return bool
	 */
	private function customer_already_reviewed( $email, $product_id ) {
		$count = get_comments(
			array(
				'post_id'      => (int) $product_id,
				'author_email' => $email,
				'type'         => 'review',
				'status'       => array( 'approve', 'hold' ),
				'count'        => true,
			)
		);

		return $count > 0;
	}

	/**
	 * Send reminder email.
	 *
	 * @param string $to Recipient email.
	 * @param string $customer_name Customer name.
	 * @param string $product_name Product name.
	 * @param string $review_link Review link.
	 * @return bool
	 */
	public function send_review_reminder_email( $to, $customer_name, $product_name, $review_link ) {
		$plugin_settings = self::get_plugin_settings();
		$email_settings  = $plugin_settings['emails'];
		$tokens          = $this->email_tokens( $customer_name, $product_name, $review_link );
		$subject         = $this->replace_tokens( $email_settings['review_reminder_subject'], $tokens );
		$body            = $this->replace_tokens( $email_settings['review_reminder_body'], $tokens );
		$heading         = $this->replace_tokens( $email_settings['review_reminder_heading'], $tokens );
		$from_name       = $plugin_settings['review_reminder']['sender_name'] ? $plugin_settings['review_reminder']['sender_name'] : $tokens['{store_name}'];

		return $this->send_configured_email( $to, $subject, $body, $heading, $from_name );
	}

	/**
	 * Send the single-coupon reward email.
	 *
	 * @param string $to Recipient.
	 * @param string $customer_name Customer name.
	 * @param string $product_name Product name.
	 * @param string $coupon_code Coupon code.
	 * @return bool
	 */
	public function send_review_discount_email( $to, $customer_name, $product_name, $coupon_code ) {
		$plugin_settings = self::get_plugin_settings();
		$email_settings  = $plugin_settings['emails'];
		$tokens          = $this->email_tokens( $customer_name, $product_name, '', $coupon_code );
		$subject         = $this->replace_tokens( $email_settings['review_discount_subject'], $tokens );
		$body            = $this->replace_tokens( $email_settings['review_discount_body'], $tokens );
		$heading         = $this->replace_tokens( $email_settings['review_discount_heading'], $tokens );
		$from_name       = $email_settings['from_name'] ? $email_settings['from_name'] : ( $plugin_settings['review_reminder']['sender_name'] ? $plugin_settings['review_reminder']['sender_name'] : $tokens['{store_name}'] );

		$discount  = $plugin_settings['review_discount'];
		$overrides = array(
			'bcc'      => $discount['email_bcc'],
			'reply_to' => $discount['email_reply_to'],
		);

		return $this->send_configured_email( $to, $subject, $body, $heading, $from_name, array_filter( $overrides ) );
	}

	/**
	 * Send configured HTML email.
	 *
	 * @param string               $to        Recipient.
	 * @param string               $subject   Subject.
	 * @param string               $body      Body.
	 * @param string               $heading   Heading.
	 * @param string               $from_name Sender name.
	 * @param array<string,string> $overrides Optional bcc / reply_to for this email.
	 * @return bool
	 */
	private function send_configured_email( $to, $subject, $body, $heading, $from_name = '', $overrides = array() ) {
		$plugin_settings = self::get_plugin_settings();
		$email_settings  = array_merge( $plugin_settings['emails'], $overrides );
		$headers         = array( 'Content-Type: text/html; charset=UTF-8' );
		$sender_name     = $from_name ? $from_name : $email_settings['from_name'];

		if ( $sender_name && ! empty( $email_settings['from_email'] ) ) {
			$headers[] = 'From: ' . $sender_name . ' <' . $email_settings['from_email'] . '>';
		}
		if ( ! empty( $email_settings['bcc'] ) ) {
			$headers[] = 'Bcc: ' . $email_settings['bcc'];
		}
		if ( ! empty( $email_settings['reply_to'] ) ) {
			$headers[] = 'Reply-To: ' . $email_settings['reply_to'];
		}

		$accent = $email_settings['accent_color'] ? $email_settings['accent_color'] : '#575ECF';

		$html = '<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;border:1px solid #e5e7eb;border-top:4px solid ' . esc_attr( $accent ) . ';border-radius:16px;">';
		$html .= '<div style="font-size:22px;font-weight:700;color:#111827;margin-bottom:12px;">' . esc_html( $heading ) . '</div>';
		// nl2br already turns newlines into breaks, so no pre-line here (it doubled every gap).
		$html .= '<div style="font-size:15px;line-height:1.7;color:#374151;">' . nl2br( make_clickable( esc_html( $body ) ) ) . '</div>';
		$html .= '<div style="margin-top:20px;font-size:12px;color:#6b7280;">' . esc_html( get_bloginfo( 'name' ) ) . '</div>';
		$html .= '</div>';

		$sent = wp_mail( $to, $subject, $html, $headers );
		Logger::log(
			'email.send',
			array(
				'to'      => $to,
				'subject' => $subject,
				'status'  => $sent ? 'sent' : 'failed',
			),
			$sent ? 'info' : 'error',
			! $sent
		);
		return $sent;
	}

	/**
	 * Replace string tokens.
	 *
	 * @param string $content Content with tokens.
	 * @param array<string, string> $tokens Tokens.
	 * @return string
	 */
	private function replace_tokens( $content, $tokens ) {
		return Tokens::replace( $content, $tokens );
	}

	/**
	 * Shared email tokens. Legacy {shop_name} and {review_url} are filled by Tokens::replace.
	 *
	 * @param string $customer_name Customer name.
	 * @param string $product_name Product name.
	 * @param string $review_link Review URL.
	 * @param string $coupon_code Coupon code.
	 * @return array<string, string>
	 */
	private function email_tokens( $customer_name, $product_name, $review_link = '', $coupon_code = '' ) {
		$settings   = self::get_plugin_settings();
		$store_name = $settings['review_reminder']['shop_name'] ? $settings['review_reminder']['shop_name'] : get_bloginfo( 'name' );

		return array(
			'{store_name}'    => $store_name,
			'{customer_name}' => $customer_name,
			'{product_name}'  => $product_name,
			'{review_link}'   => $review_link,
			'{coupon_code}'   => $coupon_code,
		);
	}
}
