<?php
namespace TSReview;

use TSReview\Helper;
use TSReview\Common;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReviewShowcase {

	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_tsreview/review_showcase/fetch', array( $self, 'get_showcase' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/fetch/single', array( $self, 'get_showcase_by_id' ) );
		add_action( 'wp_ajax_nopriv_tsreview/review_showcase/fetch/single', array( $self, 'get_showcase_by_id' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/create', array( $self, 'create_showcase' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/update', array( $self, 'update_showcase' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/update/settings', array( $self, 'update_showcase_settings' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/duplicate', array( $self, 'duplicate_showcase' ) );
		add_action( 'wp_ajax_tsreview/review_showcase/delete', array( $self, 'delete_showcase' ) );
	}

	/**
	 * Fetch all review showcases.
	 */
	public function get_showcase() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$args = array(
			'post_type' => 'ts-review-showcase',
			'posts_per_page' => -1,
			'orderby' => 'date',
			'order' => 'DESC'
		);

		$query = new \WP_Query( $args );

		if ( ! $query->have_posts() ) {
			wp_send_json_error( array( 'message' => 'No showcases found' ) );
		}

		$showcases = array();

		while ( $query->have_posts() ) {
			$query->the_post();

			$showcases[] = array(
				'post_id'   => get_the_ID(),
				'title'     => get_the_title(),
				'shortcode' => '[ts_review_showcase id="' . get_the_ID() . '"]',
				'snippet'   => '<?php echo do_shortcode(\'[ts_review_showcase id="' . get_the_ID() . '"]\'); ?>',
				'status'    => get_post_status( get_the_ID() ),
				'updated'   => get_the_modified_date( 'c', get_the_ID() ),
			);
		}

		wp_reset_postdata();

		wp_send_json_success( $showcases );
	}

	/**
	 * Fetch a single showcase by ID.
	 */
	public function get_showcase_by_id() {
		// Public, read-only data: approved reviews and a published showcase's
		// display settings. No nonce, so pages served from a page cache keep
		// working after the nonce would have expired.
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => 'Showcase not found' ) );
		}

		$args = array(
			'post_type'   => 'ts-review-showcase',
			'p'           => $post_id,
			'post_status' => current_user_can( 'manage_options' ) ? array( 'publish', 'draft', 'private' ) : 'publish',
		);

		$query = new \WP_Query( $args );

		if ( ! $query->have_posts() ) {
			wp_send_json_error( array( 'message' => 'Showcase not found' ) );
			return;
		}

		$query->the_post();
		$post_id = get_the_ID();

		$showcase_settings = get_post_meta( $post_id, 'tsreview_showcase_settings', true );
		$page              = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$per_page          = isset( $_POST['per_page'] ) ? absint( $_POST['per_page'] ) : 0;

		if ( $per_page < 1 && class_exists( __NAMESPACE__ . '\\WooCommerceIntegration' ) ) {
			$plugin_settings = WooCommerceIntegration::get_plugin_settings();
			$per_page        = isset( $plugin_settings['review_extensions']['reviews_per_page'] ) ? (int) $plugin_settings['review_extensions']['reviews_per_page'] : 6;
		}

		$per_page = max( 1, min( 24, $per_page ? $per_page : 6 ) );
		$sort     = isset( $_POST['sort'] ) ? sanitize_key( wp_unslash( $_POST['sort'] ) ) : '';
		$allowed  = array( 'recent', 'rating_high', 'rating_low' );
		if ( ! in_array( $sort, $allowed, true ) && class_exists( __NAMESPACE__ . '\\WooCommerceIntegration' ) ) {
			$plugin_settings = isset( $plugin_settings ) ? $plugin_settings : WooCommerceIntegration::get_plugin_settings();
			$sort            = $plugin_settings['review_extensions']['sort_order'] ?? 'recent';
		}
		if ( ! in_array( $sort, $allowed, true ) ) {
			$sort = 'recent';
		}
		$rating     = isset( $_POST['rating'] ) ? absint( $_POST['rating'] ) : 0;
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$query      = Helper::build_public_review_query(
			array(
				'sort'    => $sort,
				'rating'  => $rating,
				'number'  => $per_page,
				'paged'   => $page,
				'post_id' => $product_id,
			)
		);

		$showcase = array(
			'post_id'   => $post_id,
			'title'     => get_the_title( $post_id ),
			'content'   => get_the_content(),
			'meta_data' => array(
				'reviews'            => Helper::get_all_reviews( $query ),
				'reviews_total'      => Helper::count_reviews( $query ),
				'reviews_page'       => $page,
				'reviews_per_page'   => $per_page,
				'reviews_sort'       => $sort,
				'reviews_rating'     => $rating,
				'rating_summary'     => Helper::get_rating_summary( $product_id ),
				'showcase_settings'  => ! empty( $showcase_settings ) ? $showcase_settings : json_decode( Common::get_default_showcase_settings(), true ),
			),
		);

		wp_reset_postdata();
		wp_send_json_success( $showcase );
	}

	/**
	 * Create a new showcase.
	 */
	public function create_showcase() {
		check_ajax_referer( 'tsreview_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$showcase_title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$showcase_settings = isset( $_POST['data'] ) ? $this->sanitize_array( wp_unslash( $_POST['data'] ) ) : array();

		$args = array(
			'post_title'  => $showcase_title,
			'post_status' => 'publish',
			'post_author' => get_current_user_id(),
			'post_type'   => 'ts-review-showcase',
		);

		$is_post = wp_insert_post( $args, true );

		if ( ! $is_post || is_wp_error( $is_post ) ) {
			wp_send_json_error( array( 'message' => 'Failed to create showcase' ) );
			return;
		}

		// Reviews are fetched automatically, no need to store IDs
		update_post_meta( $is_post, 'tsreview_showcase_settings', $showcase_settings );
		wp_send_json_success( array( 'post_id' => $is_post ) );
	}

	/**
	 * Update an existing showcase.
	 */
	public function update_showcase() {
		check_ajax_referer( 'tsreview_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$post_id = isset( $_POST['data']['post_id'] ) ? absint( $_POST['data']['post_id'] ) : 0;

		if ( ! $this->get_editable_showcase( $post_id ) ) {
			return;
		}

		$showcase_title = isset( $_POST['data']['title'] ) ? sanitize_text_field( wp_unslash( $_POST['data']['title'] ) ) : '';

		$args = array(
			'ID'         => $post_id,
			'post_title' => $showcase_title,
		);

		$is_post = wp_update_post( $args );
		wp_send_json_success( array( 'post_id' => $is_post ) );
	}

	/**
	 * Update showcase settings.
	 */
	public function update_showcase_settings() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$showcase_settings = isset( $_POST['data'] ) ? $this->sanitize_array( wp_unslash( $_POST['data'] ) ) : array();

		if ( ! $this->get_editable_showcase( $post_id ) ) {
			return;
		}

		$args = array(
			'ID' => $post_id,
		);

		$is_post = wp_update_post( $args, true );

		if ( is_wp_error( $is_post ) ) {
			wp_send_json_error( array( 'message' => 'Failed to update showcase' ) );
			return;
		}

		update_post_meta( $post_id, 'tsreview_showcase_settings', $showcase_settings );
		wp_send_json_success( array( 'post_id' => $post_id ) );
	}

	/**
	 * Duplicate an existing showcase.
	 */
	public function duplicate_showcase() {
		check_ajax_referer( 'tsreview_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		try {
			$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;

			if ( ! $post_id ) {
				wp_send_json_error( array( 'message' => 'Invalid ID' ) );
				return;
			}

			$post = $this->get_editable_showcase( $post_id );

			if ( ! $post ) {
				return;
			}

			$showcase_settings = get_post_meta( $post_id, 'tsreview_showcase_settings', true );

			$args = array(
				'post_title'   => $post->post_title . ' (Copy)',
				'post_content' => $post->post_content,
				'post_status'  => 'publish',
				'post_author'  => get_current_user_id(),
				'post_type'    => 'ts-review-showcase',
			);

			$new_post_id = wp_insert_post( $args );

			if ( is_wp_error( $new_post_id ) ) {
				wp_send_json_error( array( 'message' => 'Failed to duplicate showcase: ' . $new_post_id->get_error_message() ) );
				return;
			}

			// Reviews are fetched automatically, no need to store IDs
			update_post_meta( $new_post_id, 'tsreview_showcase_settings', $showcase_settings );

			wp_send_json_success(
				array(
					'message' => 'Showcase duplicated successfully',
					'post_id' => $new_post_id
				)
			);
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => 'Exception occurred: ' . $e->getMessage() ) );
		}
	}

	/**
	 * Delete a showcase.
	 */
	public function delete_showcase() {
		check_ajax_referer( 'tsreview_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$post    = $this->get_editable_showcase( $post_id, 'delete_post' );

		if ( ! $post ) {
			return;
		}

		$deleted = wp_delete_post( $post_id, true );

		if ( $deleted ) {
			wp_send_json_success(
				array(
					'message' => 'Showcase deleted successfully',
					'post_id' => $post_id,
				)
			);
		} else {
			wp_send_json_error( array( 'message' => 'Failed to delete showcase' ) );
		}
	}

	/**
	 * Recursively sanitize an array.
	 *
	 * @param mixed $data The data to sanitize.
	 * @return mixed The sanitized data.
	 */
	private function sanitize_array( $data ) {
		if ( is_array( $data ) ) {
			$sanitized = array();
			foreach ( $data as $key => $value ) {
				$key = preg_replace( '/[^a-zA-Z0-9_\-]/', '', (string) $key );
				if ( '' === $key ) {
					continue;
				}
				$sanitized[ $key ] = $this->sanitize_array( $value );
			}
			return $sanitized;
		}
		return sanitize_text_field( $data );
	}

	/**
	 * Confirm the ID belongs to a showcase the current user can change.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $capability Capability to require.
	 * @return \WP_Post|null
	 */
	private function get_editable_showcase( $post_id, $capability = 'edit_post' ) {
		$post = $post_id ? get_post( $post_id ) : null;

		if ( ! $post || 'ts-review-showcase' !== $post->post_type ) {
			wp_send_json_error( array( 'message' => 'Showcase not found' ) );
			return null;
		}

		if ( ! current_user_can( $capability, $post_id ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied' ) );
			return null;
		}

		return $post;
	}
}
